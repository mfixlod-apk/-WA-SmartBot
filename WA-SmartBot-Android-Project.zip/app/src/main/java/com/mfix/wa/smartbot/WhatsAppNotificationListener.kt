package com.mfix.wa.smartbot

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class WhatsAppNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp") return

        val prefs = getSharedPreferences("bot", MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return

        // שלב הבסיס: זיהוי הודעות WhatsApp.
        // שלב הבא בפרויקט יוסיף כללים, מילות מפתח, שעות פעילות
        // ומענה דרך Action/RemoteInput כאשר ההתראה מאפשרת תשובה ישירה.
        val notification = sbn.notification ?: return
        val text = notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (text.isBlank()) return
    }
}
