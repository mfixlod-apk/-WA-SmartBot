package com.mfix.wa.smartbot

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var enabled: Switch
    private lateinit var defaultReply: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("bot", MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 56, 48, 32)
        }

        val title = TextView(this).apply {
            text = "WA SmartBot"
            textSize = 28f
        }

        status = TextView(this).apply {
            text = "בוט תשובות אוטומטיות ל-WhatsApp"
            textSize = 17f
        }

        enabled = Switch(this).apply {
            text = "הפעל בוט"
            isChecked = prefs.getBoolean("enabled", false)
        }

        defaultReply = EditText(this).apply {
            hint = "הודעת ברירת מחדל"
            setText(prefs.getString("reply", "היי 👋 תודה שפנית ל-MFIX. נחזור אליך בהקדם!"))
            minLines = 3
        }

        val save = Button(this).apply {
            text = "שמור הגדרות"
            setOnClickListener {
                prefs.edit()
                    .putBoolean("enabled", enabled.isChecked)
                    .putString("reply", defaultReply.text.toString())
                    .apply()
                Toast.makeText(this@MainActivity, "נשמר בהצלחה", Toast.LENGTH_SHORT).show()
            }
        }

        val notificationAccess = Button(this).apply {
            text = "פתח הרשאת התראות"
            setOnClickListener {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
        }

        val note = TextView(this).apply {
            text = "גרסה 1.0 • ההגדרות נשמרות במכשיר וניתן לשנות אותן בלי לבנות APK מחדש."
            textSize = 14f
        }

        layout.addView(title)
        layout.addView(space())
        layout.addView(status)
        layout.addView(space())
        layout.addView(enabled)
        layout.addView(defaultReply)
        layout.addView(save)
        layout.addView(notificationAccess)
        layout.addView(space())
        layout.addView(note)

        setContentView(layout)
    }

    private fun space(): Space = Space(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, 24)
    }
}
