package com.mfix.wa.smartbot

import android.os.Bundle
import android.graphics.Color
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    private val green = Color.rgb(37,211,102)
    private lateinit var root: LinearLayout
    private val bots = mutableListOf<Pair<String, MutableList<Pair<String,String>>>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18,18,18))
            setPadding(32, 48, 32, 24)
        }
        setContentView(root)
        showHome()
    }

    private fun clear() = root.removeAllViews()

    private fun title(t: String) {
        root.addView(TextView(this).apply {
            text = t; textSize = 28f; setTextColor(Color.WHITE)
            setTypeface(null, 1); setPadding(0,0,0,20)
        })
    }

    private fun subtitle(t: String) {
        root.addView(TextView(this).apply {
            text = t; textSize = 16f; setTextColor(Color.LTGRAY)
            setPadding(0,0,0,18)
        })
    }

    private fun button(t: String, on: () -> Unit) {
        root.addView(MaterialButton(this).apply {
            text = t; textSize = 16f; setTextColor(Color.WHITE)
            setBackgroundColor(green)
            setOnClickListener { on() }
        }, LinearLayout.LayoutParams(-1,56).apply { bottomMargin = 14 })
    }

    private fun input(hint: String): EditText {
        val e = EditText(this).apply {
            this.hint = hint; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(true); setBackgroundColor(Color.rgb(40,40,40))
            setPadding(24,0,24,0)
        }
        root.addView(e, LinearLayout.LayoutParams(-1,56).apply { bottomMargin = 14 })
        return e
    }

    private fun showHome() {
        clear()
        title("WA SmartBot")
        subtitle("בונה בוטים – אתה יוצר, משנה ומתכנן את השיחות")
        button("＋ צור בוט חדש") { showCreateBot() }

        if (bots.isEmpty()) subtitle("עדיין אין בוטים. לחץ על 'צור בוט חדש'.")
        bots.forEachIndexed { index, bot ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20,18,20,18)
                setBackgroundColor(Color.rgb(35,35,35))
                setOnClickListener { showBuilder(index) }
            }
            card.addView(TextView(this).apply {
                text = "🤖 ${bot.first}"; textSize = 20f; setTextColor(Color.WHITE)
            })
            card.addView(TextView(this).apply {
                text = "${bot.second.size} כללים פעילים"; setTextColor(Color.LTGRAY)
            })
            root.addView(card, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 12 })
        }
    }

    private fun showCreateBot() {
        clear(); title("בוט חדש"); subtitle("תן שם לבוט שלך")
        val name = input("לדוגמה: בוט שירות לקוחות")
        button("צור והמשך") {
            val n = name.text.toString().trim()
            if (n.isNotEmpty()) {
                bots.add(n to mutableListOf())
                showBuilder(bots.lastIndex)
            } else Toast.makeText(this,"צריך לתת שם לבוט",Toast.LENGTH_SHORT).show()
        }
        button("חזרה") { showHome() }
    }

    private fun showBuilder(index: Int) {
        clear()
        val bot = bots[index]
        title("🤖 ${bot.first}")
        subtitle("אם הלקוח כותב X → הבוט עונה Y")
        button("＋ הוסף כלל חדש") { showAddRule(index) }

        if (bot.second.isEmpty()) subtitle("אין עדיין כללים. התחל להוסיף תגובות.")
        bot.second.forEachIndexed { i, r ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(18,14,18,14)
                setBackgroundColor(Color.rgb(38,38,38))
                setOnClickListener { showEditRule(index,i) }
            }
            row.addView(TextView(this).apply {
                text = "אם הלקוח כותב: ${r.first}"
                setTextColor(Color.WHITE); textSize = 16f
            })
            row.addView(TextView(this).apply {
                text = "הבוט עונה: ${r.second}"
                setTextColor(Color.LTGRAY); setPadding(0,8,0,0)
            })
            root.addView(row, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 12 })
        }
        button("▶ בדוק שיחה") { showTest(index) }
        button("חזרה לבוטים") { showHome() }
    }

    private fun showAddRule(index: Int) {
        clear(); title("הוסף כלל")
        subtitle("דוגמה: 'מחיר' → 'בשמחה, איזה מוצר מעניין אותך?'")
        val trigger = input("מה הלקוח כותב?")
        val response = input("מה הבוט עונה?")
        button("שמור כלל") {
            val a = trigger.text.toString().trim()
            val b = response.text.toString().trim()
            if (a.isNotEmpty() && b.isNotEmpty()) {
                bots[index].second.add(a to b); showBuilder(index)
            } else Toast.makeText(this,"מלא את שני השדות",Toast.LENGTH_SHORT).show()
        }
        button("ביטול") { showBuilder(index) }
    }

    private fun showEditRule(index: Int, rule: Int) {
        clear(); title("עריכת כלל")
        val old = bots[index].second[rule]
        val trigger = input("מה הלקוח כותב?").apply { setText(old.first) }
        val response = input("מה הבוט עונה?").apply { setText(old.second) }
        button("שמור שינויים") {
            bots[index].second[rule] =
                trigger.text.toString() to response.text.toString()
            showBuilder(index)
        }
        button("מחק כלל") { bots[index].second.removeAt(rule); showBuilder(index) }
        button("ביטול") { showBuilder(index) }
    }

    private fun showTest(index: Int) {
        clear(); title("בדיקת הבוט")
        subtitle("כתוב הודעה כמו לקוח ובדוק איזו תשובה תתקבל")
        val message = input("כתוב הודעת לקוח")
        val result = TextView(this).apply {
            text = "התשובה תופיע כאן"
            textSize = 18f; setTextColor(Color.WHITE)
            setPadding(20,28,20,28); setBackgroundColor(Color.rgb(35,35,35))
        }
        root.addView(result, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 14 })
        button("בדוק") {
            val m = message.text.toString().trim().lowercase()
            val rule = bots[index].second.firstOrNull { m.contains(it.first.lowercase()) }
            result.text = if (rule != null) "🤖 ${rule.second}"
                          else "לא נמצאה תגובה מתאימה. אפשר להוסיף כלל חדש."
        }
        button("חזרה לעורך") { showBuilder(index) }
    }
}
